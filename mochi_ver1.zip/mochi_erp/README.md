# Mochi ERP — PHP Native MVC + MySQL

Project ini dibuat berdasarkan `database.sql` yang dilampirkan. Struktur database memiliki modul pengguna, kategori, produk, pesanan/detail pesanan, mutasi stok, akun rekening, dan jurnal keuangan.

## Fitur
- Login admin/user menggunakan `password_verify()`
- Dashboard ERP
- CRUD Kategori
- CRUD Produk
- CRUD Pengguna
- CRUD Pesanan
- CRUD Akun Rekening
- CRUD Jurnal Keuangan
- Mutasi stok/restock dan kartu stok
- Front-end katalog produk untuk user
- Bootstrap 5 responsive
- PDO prepared statements
- Upload gambar produk
- Flash message dan proteksi halaman admin

## Instalasi XAMPP
1. Ekstrak folder `mochi_erp` ke `htdocs`.
2. Import `database.sql` melalui phpMyAdmin.
3. Sesuaikan `config/database.php` bila username/password MySQL berbeda.
4. Pastikan folder `public/uploads` dapat ditulis.
5. Buka:
   `http://localhost/mochi_erp/public/`
6. Login demo:
   - Admin: `admin@mochierp.com` / `password123`
   - User: `budi@gmail.com` / `password123`

## Catatan
Database sumber menyimpan password demo dalam bentuk hash bcrypt. Aplikasi tetap menggunakan `password_verify()` dan `password_hash()` untuk password baru.
